package com.example.uipractice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
